/* SPDX-License-Identifier: LGPL-2.1-or-later */
/*
 * Copyright (C) 2019, Google Inc.
 *
 * version.h - Library version information
 *
 * This file is auto-generated. Do not edit.
 */

#pragma once

#define LIBCAMERA_VERSION_MAJOR		0
#define LIBCAMERA_VERSION_MINOR		2
#define LIBCAMERA_VERSION_PATCH		0
